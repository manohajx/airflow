class Cloud:

    def create_parser(self, argparser):
        return NotImplemented

    def set_cloud_config_from_arguments(self, arguments):
        return NotImplemented
