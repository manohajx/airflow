from setuptools import setup


setup(name='pre-commit-dummy-package', version='0.0.0')
