# Contributors

## zdesk 2

* Brent Woodruff (Fork author and maintainer)
* Matthew Jaskula (Generic parameter passing)
* Tim Allard (HTTP return code checking)
* Daniel Inniss (Porting work to `requests`)
* Dominik Miedziński (Booksy International Sp. z o. o.)
* Sarfaraz Soomro (Incremental ticket pagination)
* Craig Davis (Major `api_gen` updates for zdesk 2.6.0)


## zendesk and zdesk 1.x

* Stefan Tjarks
* Jay Chan
* Max Gutman
* J.B. Langston
* Q
* KP
* Fred Muya
* Antoine Reversat
* Vikram Oberoi
* Joe Heck
* nathanharper
* Hany Fahim
* MATSUMOTO Akihiro
* Brian Zambrano
* DemonBob
* Jeroen F.J. Laros
* Joaquin Casares
* Alex Chan
* Muya
* Nick Day
* Paul Pieralde
* Sandeep Sidhu
* ebpmp
* meowcoder
