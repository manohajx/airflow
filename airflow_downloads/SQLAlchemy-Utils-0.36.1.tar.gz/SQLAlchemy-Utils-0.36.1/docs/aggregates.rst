Aggregated attributes
=====================

.. automodule:: sqlalchemy_utils.aggregates

.. autofunction:: aggregated
