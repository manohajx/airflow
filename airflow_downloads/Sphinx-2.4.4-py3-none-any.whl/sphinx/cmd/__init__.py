"""
    sphinx.cmd
    ~~~~~~~~~~

    Modules for command line executables.

    :copyright: Copyright 2007-2020 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
