/*
 * Copyright (c) 2013-2019 Snowflake Computing
 */
#include "IntConverter.hpp"

namespace sf
{
/** this file is here for future use and if this is useless at the end, it will
 * be removed */
}  // namespace sf
