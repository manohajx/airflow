from .resource import Resource


class Attachment(Resource):

    """
    Attachment methods for a single document
    """

    pass  # lawl everything is defined by the parent class :D
