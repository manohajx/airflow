def decapitalize(key):
    return key[0].lower() + key[1:]
