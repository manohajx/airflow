# flake8: noqa

from samtranslator.sdk.resource import SamResource, SamResourceType
