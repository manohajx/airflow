=======
History
=======

1.0.0 (2019-08-10)
------------------
* Adds the helper functions to parse the qualified name
* Updates the version to 1.x to get some confidence from community as the module is pretty stable now

0.1.8 (2019-08-08)
------------------
* Add support for Atlas' Admin Metrics REST API

0.1.7 (2019-07-08)
------------------
* Add support for Atlas' DSL Saved Search (#81)
* Fixes list lookups for searching

0.1.6 (2019-04-26)
------------------
* Call of DependentClass inflate (#79) 

0.1.5 (2019-04-24)
------------------
* Add support for Post type Basic Search (#76) 


0.1.4 (2019-04-16)
------------------
* fixes (BasicSearch, when no result in _data, etc) 

0.1.3 (2019-04-05)
------------------
* HTTP Auth
* Basic search inflate
* relationshipAttributes

0.1.2 (2018-03-27)
------------------

* Bug fixes
* Response is returned after entity creation (easier to figure out the guid)

0.1.1 (2018-03-07)
------------------

* Bug fixes
* Most of the resources have been implemented (except RelationshipREST)
* Basic authentication (only the Basic token is sent on the network)

0.1.0 (2018-01-09)
------------------

* First push.


