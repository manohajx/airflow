============
Installation
============

Install the package with pip::

    $ pip install atlasclient
