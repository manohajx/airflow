fastavro.schema
===============

.. autofunction:: fastavro._schema_py.parse_schema
.. autofunction:: fastavro._schema_py.fullname
.. autofunction:: fastavro._schema_py.expand_schema
