"""
Sphinx AutoAPI
"""

from .extension import setup
