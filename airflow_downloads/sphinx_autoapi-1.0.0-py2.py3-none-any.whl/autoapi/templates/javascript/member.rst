{# Identention in this file is important #}

.. {{ obj.type }}:: {{ obj.name }}

   {{ obj.docstring|indent(3) }}


