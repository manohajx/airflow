.. {{ obj.type }}:: {{ obj.name }}

	{% if summary %}

	{{ obj.summary }}

	{% endif %}
